package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class View_or_insert extends Activity implements OnClickListener{
	
   Button view,insert;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_or_insert);
		view=(Button)findViewById(R.id.v);
		insert=(Button)findViewById(R.id.i);

		view.setOnClickListener(this);
		insert.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_or_insert, menu);
		return true;
	}

	@Override
	public void onClick(View v1) {
		// TODO Auto-generated method stub
		Intent i;
		switch(v1.getId()){
			case R.id.v:
				 i=new Intent("com.example.memorygame.Class_select");
				i.putExtra("name", "view");
				startActivity(i);
				break;
			case R.id.i:
				i=new Intent("com.example.memorygame.Class_select");
				i.putExtra("name", "insert");
				startActivity(i);
				break;

		
	}

}
	}
