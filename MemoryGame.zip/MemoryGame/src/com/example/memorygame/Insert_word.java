package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Insert_word extends Activity{
    
	EditText word,meaning;
	String level;
	Button button;
	DBhelper d;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_insert_word);
		word=(EditText)findViewById(R.id.word);
		meaning=(EditText)findViewById(R.id.meaning);
		level=getIntent().getStringExtra("name");
		button=(Button)findViewById(R.id.insert);

        d=new DBhelper(this,level);
		
		/* tv3 = (TextView) findViewById(R.id.textView1);  
		Typeface font = Typeface.createFromAsset(getAssets(), "SolaimanLipi_20-04-07.ttf");  
		tv3.setTypeface(font); 
		tv3.setText("মজা");*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.admin_log, menu);
		return true;
	}


	public void insert(View v) {
		// TODO Auto-generated method stub
		 
		String w=word.getText().toString();
		String m=meaning.getText().toString();
		Toast.makeText(getApplicationContext(), w+" "+m+" "+level, Toast.LENGTH_SHORT).show();
		
		long val=d.Insert(w,m);
		if(val>=0)
		{
			Toast.makeText(getApplicationContext(), "Successfully Inserted", Toast.LENGTH_LONG).show();
		}
		else{
			Toast.makeText(getApplicationContext(), "Insertion Failed", Toast.LENGTH_LONG).show();
		}
		
	}

}
