package com.example.memorygame;

import java.util.ArrayList;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Pl_cls_select extends Activity implements OnClickListener{
	Button play, ner,kg, std1,std2;
	DBhelper d;
	public static ArrayList<Word_dictionary>A;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pl_cls_select);
		play=(Button)findViewById(R.id.play);
		ner=(Button)findViewById(R.id.ner);
		kg=(Button)findViewById(R.id.kg);
		std1=(Button)findViewById(R.id.std1);
		std2=(Button)findViewById(R.id.std2);
		play.setOnClickListener(this);
		ner.setOnClickListener(this);
		kg.setOnClickListener(this);
		std1.setOnClickListener(this);
		std2.setOnClickListener(this);
	
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pl_cls_select, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent i;
		switch(v.getId()){
			case R.id.play:
				 i=new Intent("com.example.memorygame.Playshow");
					d=new DBhelper(this,"play");
					 A=d.getPlayWord();
				startActivity(i);
				break;
			case R.id.ner:
				i=new Intent("com.example.memorygame.Playshow");
				d=new DBhelper(this,"ner");
				 A=d.getPlayWord();
				startActivity(i);
				break;
			case R.id.kg:
				i=new Intent("com.example.memorygame.Playshow");
				d=new DBhelper(this,"kg");
				 A=d.getPlayWord();
				startActivity(i);
				break;
			case R.id.std1:
				i=new Intent("com.example.memorygame.Playshow");
				d=new DBhelper(this,"std1");
				 A=d.getPlayWord();
				startActivity(i);
				break;
			case R.id.std2:
				 i=new Intent("com.example.memorygame.Playshow");
				 d=new DBhelper(this,"std2");
				 A=d.getPlayWord();
				 startActivity(i);
				break;
		}

		
	}

}
