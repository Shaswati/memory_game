package com.example.memorygame;



import java.util.ArrayList;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class DBhelper extends SQLiteOpenHelper {
	
	public String level="";
	public static final String DB_Name="Memory";
	public static final int DB_version=1;
	
	public static final String  name_table1="play";
	public static final String  name_table2="nersary";
	public static final String  name_table3="kg";
	public static final String  name_table4="std1";
	public static final String  name_table5="std2";
	public static final String WORD_FIELD="word";
	public static final String MEANING_FIELD="meaning";
	
	public static final String CREATE_COM1="CREATE TABLE "+name_table1+" ("+WORD_FIELD+" TEXT, "+MEANING_FIELD+" TEXT)";
	public static final String CREATE_COM2="CREATE TABLE "+name_table2+" ("+WORD_FIELD+" TEXT, "+MEANING_FIELD+" TEXT)";
	public static final String CREATE_COM3="CREATE TABLE "+name_table3+" ("+WORD_FIELD+" TEXT, "+MEANING_FIELD+" TEXT)";
	public static final String CREATE_COM4="CREATE TABLE "+name_table4+" ("+WORD_FIELD+" TEXT, "+MEANING_FIELD+" TEXT)";
	public static final String CREATE_COM5="CREATE TABLE "+name_table5+" ("+WORD_FIELD+" TEXT, "+MEANING_FIELD+" TEXT)";
			


	public DBhelper(Context context,String s) {
		super(context, DB_Name, null, DB_version);
		// TODO Auto-generated constructor stub
		    level=s;
		   // name_table=level;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL(CREATE_COM1);
		db.execSQL(CREATE_COM2);
		db.execSQL(CREATE_COM3);
		db.execSQL(CREATE_COM4);
		db.execSQL(CREATE_COM5);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}
	public long Insert(String a,String b){
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues C=new ContentValues();
		long val=0;
		C.put(WORD_FIELD, a);
		C.put(MEANING_FIELD, b);
		if(level.matches("play"))
		val=db.insert(name_table1, null, C);
		else if(level.matches("ner"))
			val=db.insert(name_table2, null, C);
		else if(level.matches("kg"))
			val=db.insert(name_table3, null, C);
		else if(level.matches("std1"))
			val=db.insert(name_table4, null, C);
		else if(level.matches("std2"))
			val=db.insert(name_table5, null, C);
		db.close();
		return val;
	}

	public String getData() {
		// TODO Auto-generated method stub
		SQLiteDatabase db=this.getReadableDatabase();
		String[] cols={WORD_FIELD,MEANING_FIELD};
		Cursor cursor= db.query(name_table1, cols, null, null, null, null, null);
		String result="";
		    if(level.matches("play"))
		    cursor= db.query(name_table1, cols, null, null, null, null, null);
			else if(level.matches("ner"))
		    cursor= db.query(name_table2, cols, null, null, null, null, null);
			else if(level.matches("kg"))
		    cursor= db.query(name_table3, cols, null, null, null, null, null);
			else if(level.matches("std1"))
			cursor= db.query(name_table4, cols, null, null, null, null, null);
			else if(level.matches("std2"))
			cursor= db.query(name_table5, cols, null, null, null, null, null);
		
		
		if(cursor!=null && cursor.getCount()>0)
		{
			cursor.moveToFirst();
			for(int i=0;i<cursor.getCount();i++){
				String w=cursor.getString(cursor.getColumnIndex(WORD_FIELD));
				String m=cursor.getString(cursor.getColumnIndex(MEANING_FIELD));
				result+=w+"\t\t\t\t\t\t"+m+"\n";
			    cursor.moveToNext();
			}
		}
		cursor.close();
		db.close();
		return result;
		
		
	}

	public ArrayList<Word_dictionary> getPlayWord() {
		// TODO Auto-generated method stub
		ArrayList<Word_dictionary> all=new ArrayList<Word_dictionary>();
		SQLiteDatabase db=this.getReadableDatabase();
		String[] cols={WORD_FIELD,MEANING_FIELD};
		Cursor cursor= db.query(name_table1, cols, null, null, null, null, null);
		String result="";
		    if(level.matches("play"))
		    cursor= db.query(name_table1, cols, null, null, null, null, null);
			else if(level.matches("ner"))
		    cursor= db.query(name_table2, cols, null, null, null, null, null);
			else if(level.matches("kg"))
		    cursor= db.query(name_table3, cols, null, null, null, null, null);
			else if(level.matches("std1"))
			cursor= db.query(name_table4, cols, null, null, null, null, null);
			else if(level.matches("std2"))
			cursor= db.query(name_table5, cols, null, null, null, null, null);
		
		    if(cursor!=null && cursor.getCount()>0)
			{
				cursor.moveToFirst();
				for(int i=0;i<cursor.getCount();i++){
					String w=cursor.getString(cursor.getColumnIndex(WORD_FIELD));
					String m=cursor.getString(cursor.getColumnIndex(MEANING_FIELD));
					Word_dictionary p=new Word_dictionary(w,m);
					all.add(p);
					cursor.moveToNext();
				}
			}
			cursor.close();
			db.close();
			return all;
		
	}

}
