package com.example.memorygame;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Nextlevel extends Activity{
     Button b,c;
   MediaPlayer music;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_nextlevel);
		music=MediaPlayer.create(this, R.raw.game);
		music.start();
		b=(Button)findViewById(R.id.buttonagain);
		c=(Button)findViewById(R.id.buttonnext);

		/*if(Writeword.flag==1){
			//Toast.makeText(getApplicationContext(), "correct", Toast.LENGTH_SHORT).show();
			b.setVisibility(Button.INVISIBLE);
		}
		else 
		{
			c.setVisibility(Button.INVISIBLE);
			if(Wordplay.count==0 || Wordplay.count==1 || Wordplay.count==2)
				Wordplay.count=0;
			else
			Wordplay.count=Wordplay.count/3*3-1;
		//	Toast.makeText(getApplicationContext(), ""+Wordplay.count, Toast.LENGTH_SHORT).show();
		}*/
	}
	
	public void next(View V){
		Intent a=new Intent(this,Wordplay.class);
		startActivity(a);
	}
	public void again(View V){
		Intent a=new Intent(this,Wordplay.class);
		startActivity(a);
	}
	public void score(View V){
		Intent a=new Intent(this,Highscore.class);
		startActivity(a);
	}
	public void store(View V){
		Intent a=new Intent(this,Store.class);
		startActivity(a);
	}
	public void quit(View V){
		Intent a=new Intent(this,MainActivity.class);
		startActivity(a);
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		music.release();
		finish();
	}

}
