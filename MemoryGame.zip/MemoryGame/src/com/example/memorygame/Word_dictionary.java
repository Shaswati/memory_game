package com.example.memorygame;

public class Word_dictionary {
        private String word,meaning;

		public String getWord() {
			return word;
		}

		public void setWord(String word) {
			this.word = word;
		}

		public String getMeaning() {
			return meaning;
		}

		public void setMeaning(String meaning) {
			this.meaning = meaning;
		}

		public Word_dictionary(String word, String meaning) {
			super();
			this.word = word;
			this.meaning = meaning;
		}

		@Override
		public String toString() {
			return   word;
		}

	
}
