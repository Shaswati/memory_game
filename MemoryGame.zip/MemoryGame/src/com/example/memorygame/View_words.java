package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;

public class View_words extends Activity {
     String type,result;
     DBhelper d;
     TextView tv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_words);
		tv=(TextView)findViewById(R.id.getdata);
		type=getIntent().getStringExtra("name");
		d=new DBhelper(this,type);
		result=d.getData();
		tv.setText(result);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_words, menu);
		return true;
	}

}
