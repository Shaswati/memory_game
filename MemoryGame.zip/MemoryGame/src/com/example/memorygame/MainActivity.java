package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener{
    Button play,store,help,high;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		play=(Button)findViewById(R.id.play);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void selectgame(View V){
		
		 Intent abc=new Intent(this,Selectgame.class);
		   startActivity(abc);
	}
	public void highscore(View V){
		
		 Intent high=new Intent(this,Highscore.class);
		   startActivity(high);
	}
	public void store(View V){
		
		 Intent s=new Intent(this,Store.class);
		   startActivity(s);
	}
	public void help(View V){
		
		 Intent h=new Intent(this,Help.class);
		   startActivity(h);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}
}
