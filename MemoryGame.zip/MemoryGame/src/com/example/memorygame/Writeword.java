package com.example.memorygame;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Writeword extends Activity {
 TextView timer,msg;
 EditText e;
 Button b;
 String w;
	CountDownTimer tim;
	MediaPlayer music;
	
 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_writeword);
		music=MediaPlayer.create(this, R.raw.game);
		music.start();
		timer=(TextView)findViewById(R.id.ttt);
		msg=(TextView)findViewById(R.id.textView2);
		e=(EditText)findViewById(R.id.editText1);
		b=(Button)findViewById(R.id.button1);
		w=getIntent().getStringExtra("wd");
		//Toast.makeText(getApplicationContext(),w, Toast.LENGTH_LONG).show();
			tim=new CountDownTimer(15000, 1000) {

		     public void onTick(long millisUntilFinished) {
		         timer.setText("00:0" + millisUntilFinished / 1000);
		        
		     }

		     public void onFinish() {
		    	
		    	 e.setVisibility(EditText.INVISIBLE);
		    	 b.setVisibility(Button.INVISIBLE);
		    	 timer.setText("00.00");	    	 
		    	 msg.setText("Time Up!!!");
		    	 Playshow.count--;
		    	
		    	 change();
		     }
		  }.start();
		

	        b.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					tim.cancel();
					
					 String val1=e.getText().toString();
					
				        if(val1.equalsIgnoreCase(w)==true)
				            {
				        
				            	e.setVisibility(EditText.INVISIBLE);
						    	 b.setVisibility(Button.INVISIBLE);
						    	 w="You Are Correct\n"+w+"\nMeaning: "+Pl_cls_select.A.get(Playshow.count-1).getMeaning();
							     msg.setText(w);
				         		 change();
				            }
				       else
				            {
				        	 e.setVisibility(EditText.INVISIBLE);
					    	 b.setVisibility(Button.INVISIBLE);
					    	 msg.setText("Sorry Try Again");
					    	 Playshow.count--;
			         		 change();
				        	
				            }
				}
				});
	    
	
		
	}
	public void change()
	{    
		new CountDownTimer(6000, 1000) {

		     public void onTick(long millisUntilFinished) {
		    //	t1.setText("00:0" + millisUntilFinished / 1000);
		    	 
		     }

		     public void onFinish() {
                  callplay();
		     }
		  }.start();	
	}
public void callplay()
{
	Intent i=new Intent("com.example.memorygame.Playshow");
    startActivity(i);
	
}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.writeword, menu);
		return true;
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		music.release();
		finish();
	}


}
