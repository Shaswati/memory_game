package com.example.memorygame;

public class dictionary {
          public static final String s[] ={"book","pencil","school","computer","river","genius","syllebus",};
        
}
