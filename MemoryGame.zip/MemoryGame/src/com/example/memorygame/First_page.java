package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class First_page extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_first_page);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.first_page, menu);
		return true;
	}
	
	public void player_log(View v){
		Intent abc=new Intent("com.example.memorygame.Pl_cls_select");
		 
		 startActivity(abc);
		
	}
	public void admin_log(View v){
		Intent abc=new Intent("com.example.memorygame.Login");
		 
		 startActivity(abc);
		
	}
	

}
