package com.example.memorygame;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

public class Playshow extends Activity {
    TextView word,t;
    String a;
    public static  int count=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_playshow);
		word=(TextView)findViewById(R.id.guess);
		t=(TextView)findViewById(R.id.time);
		word.setText(Pl_cls_select.A.get(count).toString());
		count++;
		a=word.getText().toString();
		//call();
		CountDownTimer ti=new CountDownTimer(6000, 1000) {

		     public void onTick(long millisUntilFinished) {
		    	 t.setText("00:0" + millisUntilFinished / 1000);
		     }

		     public void onFinish() {
		    	 t.setText("00:00");	
		    	 	call();
			
		    	 
	
		     }
		  };
		  ti.start();
	}
	public void call()
	{
		Toast.makeText(getApplicationContext(),"call a"+a, Toast.LENGTH_LONG).show();

		Intent i=new Intent("com.example.memorygame.Writeword");
	 	i.putExtra("wd", a);
	    startActivity(i);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.playshow, menu);
		return true;
	}

}
