package com.example.memorygame;

import java.util.Random;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

public class Wordplay extends Activity {
     TextView t,t1,t2;
     public String[] a=new String[100];
     public static  int count=0;
 	int j=0,index=0,i=5;
 	MediaPlayer music;
     
     
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	   count++;
	    
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wordplay);
		music=MediaPlayer.create(this, R.raw.game);
		music.start();
		
		t=(TextView)findViewById(R.id.textView2);
		//t1=(TextView)findViewById(R.id.timer);
	//	t2=(TextView)findViewById(R.id.textViewlevel);
		t2.setText("Level: "+count);
		Random r=new Random();
		int n=r.nextInt(24);
		a[index++]=dictionary.s[n];
		t.setText(dictionary.s[n]);
	
		
			
			t.setText(dictionary.s[n]);	
			CountDownTimer time=new CountDownTimer(3000, 1000) {

			     public void onTick(long millisUntilFinished) {
			         t1.setText("00:0" + millisUntilFinished / 1000);
			     }

			     public void onFinish() {
			    	 	
			    	  j++;
			    	 if(j==count)
			    	 {
			    	   cancel();
			    	   change();
			    	 }
			    	 else{
			    	 Random r=new Random();
						int n=r.nextInt(7);
						a[index++]=dictionary.s[n];
					    t.setText(dictionary.s[n]);
			    	 start();
			    	 }
			    	 
		
			     }
			  };
			  time.start();
			
	    }
		     
	
	public void change()
	{

                Intent abc=new Intent("com.example.memorygame.Writeword");
				abc.putExtra("array", a);
				abc.putExtra("Number", i);
			    startActivity(abc);
		
	}
		

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.wordplay, menu);
		return true;
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		music.release();
		finish();
	}

}
