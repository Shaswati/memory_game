package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class Class_select extends Activity implements OnClickListener {

	Button play, ner,kg, std1,std2;
	String type,cls;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_class_select);
		play=(Button)findViewById(R.id.play);
		ner=(Button)findViewById(R.id.ner);
		kg=(Button)findViewById(R.id.kg);
		std1=(Button)findViewById(R.id.std1);
		std2=(Button)findViewById(R.id.std2);
		play.setOnClickListener(this);
		ner.setOnClickListener(this);
		kg.setOnClickListener(this);
		std1.setOnClickListener(this);
		std2.setOnClickListener(this);
		type=getIntent().getStringExtra("name");
		
		if(type.matches("view"))
			cls="View_words";
			
		else cls="Insert_word";
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.class_select, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
			Intent i;
		switch(v.getId()){
			case R.id.play:
				 i=new Intent("com.example.memorygame."+cls);
				i.putExtra("name", "play");
				startActivity(i);
				break;
			case R.id.ner:
				i=new Intent("com.example.memorygame."+cls);
				i.putExtra("name", "ner");
				startActivity(i);
				break;
			case R.id.kg:
				i=new Intent("com.example.memorygame."+cls);
				i.putExtra("name", "kg");
				startActivity(i);
				break;
			case R.id.std1:
				i=new Intent("com.example.memorygame."+cls);
				i.putExtra("name", "std1");
				startActivity(i);
				break;
			case R.id.std2:
				 i=new Intent("com.example.memorygame."+cls);
				i.putExtra("name", "std2");
				startActivity(i);
				break;
		}
	}

}
