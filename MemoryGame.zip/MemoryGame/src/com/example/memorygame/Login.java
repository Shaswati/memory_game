package com.example.memorygame;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity {

	EditText name1,pass1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		name1=(EditText)findViewById(R.id.name);
		pass1=(EditText)findViewById(R.id.pass);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}
	
	public void Login(View v){
		String n=name1.getText().toString();
		String p=pass1.getText().toString();
		if(n.matches("admin") && p.matches("12345")){
			Intent a=new Intent("com.example.memorygame.View_or_insert");
			startActivity(a);
			
		}
		else
		{
			 Toast.makeText(getApplicationContext(),"Login Failed", Toast.LENGTH_SHORT).show();
				
			
		}
	}

}
